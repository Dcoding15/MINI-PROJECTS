from django.shortcuts import render
from random import randrange

game_box = {}
info_game = {}
player_chance = "X"
win_moves = [
    ['1','2','3'],
    ['4','5','6'],
    ['7','8','9'],
    ['1','4','7'],
    ['2','5','8'],
    ['3','6','9'],
    ['1','5','9'],
    ['3','5','7']
]

def check_winner(game_box):
    for i in win_moves:
        pos = [game_box.get(j) for j in i]
        if len(set(pos)) == 1 and pos[0] is not None:
            return pos[0]
    return None

def tictactoe_game(request):
    info_game = {
        "score_board": {
            "player_1":'',
            "player_2":'',
        }
    }
    info_game['score_board']['player_1'] = ''
    info_game['score_board']['player_2'] = ''
    global player_chance, game_box
    player_chance = "X"
    game_box = {}
    return render(request,"index.html",info_game)

def two_player_game(request):
    global player_chance
    info_game = {
        "score_board": {
            "player_1":'',
            "player_2":'',
        },
        "game_box":game_box
    }
    box = [
        request.POST.get("box1"),
        request.POST.get("box2"),
        request.POST.get("box3"),
        request.POST.get("box4"),
        request.POST.get("box5"),
        request.POST.get("box6"),
        request.POST.get("box7"),
        request.POST.get("box8"),
        request.POST.get("box9")
    ]
    if len(game_box) <= 9:
        for i in box:
            if i == None:
                continue
            else:
                if i in game_box:
                    continue
                else:
                    game_box[i] = player_chance
                    if player_chance == "X":
                        player_chance = "O"
                    elif player_chance == "O":
                        player_chance = "X"
        if check_winner(game_box) == "X":
            info_game['score_board']['player_1'] = "WINNER"
            info_game['score_board']['player_2'] = "LOOSER"
        elif check_winner(game_box) == "O":
            info_game['score_board']['player_2'] = "WINNER"
            info_game['score_board']['player_1'] = "LOOSER"
        elif check_winner(game_box) == None:
            info_game['score_board']['player_1'] = ""
            info_game['score_board']['player_2'] = ""
    return render(request,"twoplayer.html",info_game)