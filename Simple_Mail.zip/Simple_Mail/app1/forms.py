from django import forms
from .models import MailDB
# forms.py
class Mail_Form(forms.ModelForm):
    class Meta:
        model = MailDB
        fields = '__all__'
        widgets = {
            'mail_date': forms.DateInput(attrs={'type': 'date'}),
        }