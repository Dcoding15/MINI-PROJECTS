from django.db import models

# Create your models here.
class MailDB(models.Model):
    sender_name = models.CharField(max_length=100)
    sender_mail = models.EmailField()
    mail_date = models.DateTimeField()
    subject = models.CharField(max_length=100)
    mail_body = models.TextField()

    def __str__(self):
        return f"{self.sender_name} --> {self.sender_mail}"