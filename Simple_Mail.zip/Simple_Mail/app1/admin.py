from django.contrib import admin
from .models import MailDB

# Register your models here.
admin.site.register(MailDB)