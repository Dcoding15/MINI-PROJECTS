from django.shortcuts import render, redirect
from django.core.mail import send_mail
from django.conf import settings
from .forms import Mail_Form

# Create your views here.
def page1(request):
    if request.method == 'POST':
        mail_form = Mail_Form(request.POST)
        if mail_form.is_valid():
            mail_object = mail_form.save()
            send_mail(subject=mail_object.subject,message=mail_object.mail_body,from_email=settings.EMAIL_HOST_USER,recipient_list=[settings.EMAIL_HOST_USER])
            return page2(request)
    else:
        mail_form = Mail_Form()
    return render(request, 'index.html', {'form':mail_form})

def page2(request):
    return render(request, 'thankyou.html')