from django.db import models

Y_N = (
    ("Yes","Yes"),
    ("No","No")
)
GENDER = (
    ('Male', 'Male'),
    ('Female', 'Female')
)
NOTIFICATION_TYPES = (
    ('Booked', 'Booked'),
    ('Confirmed', 'Confirmed'),
    ('Cancelled', 'Cancelled'),
    ('Rescheduled', 'Rescheduled'),
)
class Patient(models.Model):
    uid = models.AutoField(primary_key=True)
    username = models.CharField(max_length=100)
    email = models.CharField(max_length=100)
    password = models.CharField(max_length=30)
    phone_number = models.CharField(max_length=15)
    date_of_birth = models.DateField()
    gender = models.CharField(max_length=7, choices=GENDER)
    is_active = models.CharField(choices=Y_N, default="No")
    date_created = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.username

class Doctor(models.Model):
    uid = models.AutoField(primary_key=True)
    username = models.CharField(max_length=100)
    email = models.CharField(max_length=100)
    password = models.CharField(max_length=30)
    phone_number = models.CharField(max_length=15)
    date_of_birth = models.DateField()
    gender = models.CharField(max_length=7, choices=GENDER)
    is_active = models.CharField(choices=Y_N, default="No")
    specialization = models.CharField(max_length=100)
    experience_years = models.PositiveIntegerField()
    qualification = models.TextField()
    clinic_address = models.TextField()
    consultation_fee = models.DecimalField(max_digits=8, decimal_places=2)
    license_document = models.FileField(upload_to="licenses/", null=True, blank=True)
    date_created = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.username

class Availability(models.Model):
    doctor = models.ForeignKey(Doctor, on_delete=models.CASCADE)
    day_of_week = models.DateField()
    log_time = models.TimeField()
    is_available = models.BooleanField(default=False)

class Appointment(models.Model):
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE)
    doctor = models.ForeignKey(Doctor, on_delete=models.CASCADE)
    appointment_date_time = models.DateTimeField()
    medical_history_summary = models.ImageField(upload_to="medical_history/", null=True, blank=True)

class Notification(models.Model):
    user1 = models.ForeignKey(Patient, on_delete=models.CASCADE)
    user2 = models.ForeignKey(Doctor, on_delete=models.CASCADE)
    message = models.TextField(max_length=500)
    notf_type = models.CharField(max_length=20, choices=NOTIFICATION_TYPES)
    timestamp = models.DateTimeField(auto_now_add=True)