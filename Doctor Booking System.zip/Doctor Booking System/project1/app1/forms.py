from django import forms
from .models import *

class PatientForm(forms.ModelForm):
    class Meta:
        model = Patient
        fields = ["username", "email", "password", "phone_number", "date_of_birth", "gender"]

    username = forms.CharField(
        max_length=100,
        required=True,
        widget=forms.TextInput(attrs={'placeholder': 'Enter username'})
    )
    email = forms.EmailField(
        required=True,
        widget=forms.EmailInput(attrs={'placeholder': 'Enter email'})
    )
    password = forms.CharField(
        max_length=30,
        required=True,
        widget=forms.PasswordInput(attrs={'placeholder': 'Enter password'})
    )
    phone_number = forms.CharField(
        max_length=15,
        required=True,
        widget=forms.TextInput(attrs={'placeholder': 'Enter phone number'})
    )
    date_of_birth = forms.DateField(
        required=True,
        widget=forms.DateInput(attrs={'type': 'date'})
    )
    gender = forms.ChoiceField(
        choices=[('Male', 'Male'), ('Female', 'Female')],
        required=True,
        widget=forms.Select()
    )

class DoctorForm(forms.ModelForm):
    class Meta:
        model = Doctor
        fields = ["username", "email", "password", "phone_number", "date_of_birth", "gender", 
                  "specialization", "experience_years", "clinic_address", "qualification", 
                  "license_document", "consultation_fee"]

    username = forms.CharField(
        max_length=100,
        required=True,
        widget=forms.TextInput(attrs={'placeholder': 'Enter username'})
    )
    email = forms.EmailField(
        required=True,
        widget=forms.EmailInput(attrs={'placeholder': 'Enter email'})
    )
    password = forms.CharField(
        max_length=30,
        required=True,
        widget=forms.PasswordInput(attrs={'placeholder': 'Enter password'})
    )
    phone_number = forms.CharField(
        max_length=15,
        required=True,
        widget=forms.TextInput(attrs={'placeholder': 'Enter phone number'})
    )
    date_of_birth = forms.DateField(
        required=True,
        widget=forms.DateInput(attrs={'type': 'date',})
    )
    gender = forms.ChoiceField(
        choices=[('Male', 'Male'), ('F', 'Female')],
        required=True,
        widget=forms.Select()
    )
    specialization = forms.CharField(
        max_length=100,
        required=True,
        widget=forms.TextInput(attrs={'placeholder': 'Enter specialization'})
    )
    experience_years = forms.IntegerField(
        required=True,
        widget=forms.NumberInput(attrs={'placeholder': 'Enter years of experience'})
    )
    clinic_address = forms.CharField(
        max_length=255,
        required=True,
        widget=forms.TextInput(attrs={'placeholder': 'Enter clinic address'})
    )
    qualification = forms.CharField(
        max_length=255,
        required=True,
        widget=forms.TextInput(attrs={'placeholder': 'Enter qualification'})
    )
    license_document = forms.FileField(
        required=True,
        widget=forms.ClearableFileInput()
    )
    consultation_fee = forms.DecimalField(
        required=True,
        widget=forms.NumberInput(attrs={'placeholder': 'Enter consultation fee'})
    )

class AppointmentForm(forms.ModelForm):
    class Meta:
        model = Appointment
        fields = ["doctor", "appointment_date_time", "medical_history_summary"]
    
    appointment_date_time = forms.DateTimeField(
        input_formats=['%b. %d, %Y, %I:%M %p'],
        widget=forms.DateTimeInput(format='%b. %d, %Y, %I:%M %p',attrs={'type':'datetime-local'}),
    )

class NotificationForm1(forms.ModelForm):
    class Meta:
        model = Notification
        fields = ["user1","message","notf_type"]

class NotificationForm2(forms.ModelForm):
    class Meta:
        model = Notification
        fields = ["user2","message"]

class LoginForm(forms.Form):
    username = forms.CharField(
        max_length=100,
        required=True,
        widget=forms.TextInput(attrs={'placeholder': 'Enter your username',})
    )
    password = forms.CharField(
        max_length=30,
        required=True,
        widget=forms.PasswordInput(attrs={'placeholder': 'Enter your password',})
    )
