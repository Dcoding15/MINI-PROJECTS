from django.contrib import admin
from .models import Patient, Doctor, Availability, Appointment, Notification


@admin.register(Patient)
class PatientAdmin(admin.ModelAdmin):
    list_display = ("uid","username","email", "password", "phone_number", "date_of_birth", "gender", "is_active", "date_created")
    ordering = ("date_created",)


@admin.register(Doctor)
class DoctorAdmin(admin.ModelAdmin):
    list_display = ("uid","username","email", "password", "phone_number", "date_of_birth", "gender", "is_active", "specialization", "experience_years", "clinic_address", "qualification", "license_document", "consultation_fee", "date_created")
    orderding = ("-experience_years",)


@admin.register(Availability)
class AvailabilityAdmin(admin.ModelAdmin):
    list_display = ("doctor__username", "day_of_week", "log_time", "is_available")
    list_filter = ("day_of_week", "is_available")
    search_fields = ("doctor__username", "doctor__specialization")


@admin.register(Appointment)
class AppointmentAdmin(admin.ModelAdmin):
    list_display = ("patient__username", "doctor__username", "appointment_date_time", "medical_history_summary")
    list_filter = ("appointment_date_time",)
    search_fields = ("user__username", "doctor__user__username")
    ordering = ("-appointment_date_time",)


@admin.register(Notification)
class NotificationAdmin(admin.ModelAdmin):
    list_display = ("user1__username", "user2__username", "notf_type", "timestamp")
    list_filter = ("notf_type",)
    search_fields = ("user1__username", "user2__username")
    ordering = ("-timestamp",)