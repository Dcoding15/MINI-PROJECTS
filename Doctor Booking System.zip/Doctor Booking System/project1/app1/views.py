from django.shortcuts import render, redirect
from .models import *
from .forms import *
from datetime import datetime

# Create your views here.
def home_page(request):
    available_doctor = Availability.objects.filter(is_available=True).all()
    return render(request, 'home.html', {'active_doctor':available_doctor})

def patient_profile(request, patient_user):
    data = Patient.objects.filter(uid=patient_user).first()
    ntf_data = Notification.objects.filter(user1=data).all()
    if data != None and data.is_active != "Yes":
            return redirect('/login')
    if request.method == 'POST' and data is not None:
        form = NotificationForm2(request.POST)
        if form.is_valid() and request.POST.get('upload') == 'upload':
            Notification(
                user1=data,
                user2=form.cleaned_data['user2'],
                message=form.cleaned_data['message']
            ).save()
            return redirect(f'/patient-profile/{patient_user}')
        if request.POST.get('logout') == "logout":
            data.is_active = "No"
            data.save(force_update=True)
            return redirect('/login')
        if request.POST.get('app_make') == "app_make":
            return redirect(f'/appointment-page/{patient_user}')
    else:
        form = NotificationForm2()
    return render(request, 'patient1.html',{'data':data,'ntf_data':ntf_data, 'form':form})
    

def doctor_profile(request, doctor_user):
    data = Doctor.objects.filter(uid=doctor_user).first()
    ntf_data = Notification.objects.filter(user2=data).all() if data else []
    active_doctor = Availability.objects.filter(doctor=data).first()
    if active_doctor == None:
        Availability(
            doctor=data,
            day_of_week=datetime.now().date(),
            log_time = datetime.now().time(),
            is_available = True
        ).save()
    if active_doctor != None and active_doctor.is_available == False:
        active_doctor.day_of_week=datetime.now().date()
        active_doctor.log_time = datetime.now().time()
        active_doctor.is_available = True
        active_doctor.save()
    if data is not None and data.is_active != "Yes":
        return redirect('/login')
    if request.method == 'POST' and data is not None:
        form = NotificationForm1(request.POST)
        if form.is_valid() and request.POST.get('upload') == 'upload':
            Notification(
                user1=form.cleaned_data['user1'],
                user2=data,
                message=form.cleaned_data['message'],
                notf_type=form.cleaned_data['notf_type']
            ).save()
            return redirect(f'/doctor-profile/{doctor_user}')
        if request.POST.get('logout') == "logout":
            if active_doctor != None:
                active_doctor.log_time = datetime.now().time()
                active_doctor.is_available = False
                active_doctor.save()
            data.is_active = "No"
            data.save()
            return redirect('/login')
    else:
        form = NotificationForm1()
    return render(request, 'doctor1.html', {'data':data, 'ntf_data':ntf_data, 'form':form})

def login_page(request):
    if request.method == 'POST':
        if request.POST.get('reset') == "reset":
            pass
        form = LoginForm(request.POST)
        if form.is_valid():
            uname = form.cleaned_data['username']
            passwd = form.cleaned_data['password']
            patient_active = Patient.objects.filter(username=uname,password=passwd).first()
            doctor_active = Doctor.objects.filter(username=uname,password=passwd).first()
            if patient_active != None:
                patient_active.is_active = "Yes"
                patient_active.save()
                return redirect(f'/patient-profile/{patient_active.uid}')
            elif doctor_active != None:
                doctor_active.is_active = "Yes"
                doctor_active.save()
                return redirect(f'/doctor-profile/{doctor_active.uid}')
            else:
                return redirect('/login')
    else:
        form = LoginForm()
    return render(request, 'login.html', {'form':form})

def patient_registraion_page(request):
    if request.method == 'POST':
        form = PatientForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('/login')
    else:
        form = PatientForm()
    return render(request, 'patient2.html', {'form':form})

def doctor_registraion_page(request):
    if request.method == 'POST':
        form = DoctorForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('login/')
    else:
        form = DoctorForm()
    return render(request, 'doctor2.html', {'form':form})

def registration_page(request):
    patient_form = PatientForm()
    doctor_form = DoctorForm()
    if request.method == 'POST':
        if request.POST.get('patient') == 'patient_form':
            patient_form = PatientForm(request.POST)
            if patient_form.is_valid():
                patient_form.save()
                return redirect('/login')
        if request.POST.get('doctor') == 'doctor_form':
            doctor_form = PatientForm(request.POST, request.FILES)
            if doctor_form.is_valid():
                doctor_form.save()
                return redirect('/login')
    return render(request, 'registration.html', {'patient_form':patient_form, 'doctor_form':doctor_form})
        

def appointment_page(request, patient_user):
    patient_active = Patient.objects.get(uid=patient_user)
    if patient_active.is_active != "Yes":
        return redirect('/login')
    if request.method  == 'POST':
        form = AppointmentForm(request.POST, request.FILES)
        if form.is_valid():
            obj = Appointment(
                patient=patient_active,
                doctor=form.cleaned_data['doctor'],
                appointment_date_time=form.cleaned_data['appointment_date_time'],
                medical_history_summary=form.cleaned_data['medical_history_summary']
            )
            obj2 = Notification(
                user1=patient_active,
                user2=form.cleaned_data['doctor'],
                message=f"Appointment for {patient_active} is fixed with {form.cleaned_data['doctor']} at {form.cleaned_data['appointment_date_time']}",
                notf_type="Booked"
            )
            obj.save()
            obj2.save()
            return redirect(f'/patient-profile/{patient_user}')
    else:
        form = AppointmentForm()
    return render(request, 'appointment.html', {'form':form})