from django.shortcuts import render, redirect, get_object_or_404

# Create your views here.
from .models import Task
from datetime import datetime

def task_list(request):
    if request.method == 'POST':
        title = request.POST.get('title')
        due_date = request.POST.get('due_date')
        if title:
            Task.objects.create(title=title,due_date=due_date)
        return redirect('task_list')

    tasks = Task.objects.all().order_by('-created')
    return render(request, 'index.html', {'tasks': tasks})


def toggle_task(request, pk):
    task = get_object_or_404(Task, pk=pk)
    task.completed = not task.completed
    task.save()
    return redirect('task_list')


def delete_task(request, pk):
    task = get_object_or_404(Task, pk=pk)
    task.delete()
    return redirect('task_list')