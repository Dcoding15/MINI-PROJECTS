from django.urls import path
from . import views

urlpatterns = [
    path('home/', views.task_list, name='task_list'),
    path('toggle/<int:pk>/', views.toggle_task, name='toggle'),
    path('delete/<int:pk>/', views.delete_task, name='delete'),
]